function FormularÖffnen() {
  document.getElementById("Antrag-Fenster").style.visibility = "visible";
}

function FormularSchließen() {
  document.getElementById("Antrag-Fenster").style.visibility = "hidden";
}


function Absenden(){
  document.getElementById("Submit-Button").innerHTML ="Danke!";
  setTimeout(function() { FormularSchließen(); }, 2000);

}
